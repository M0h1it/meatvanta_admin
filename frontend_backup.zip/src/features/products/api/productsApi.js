import apiClient from "../../../lib/apiClient";

export async function fetchProducts({ categoryId, includeInactive = true } = {}) {
  const { data } = await apiClient.get("/products", { params: { categoryId, includeInactive } });
  return data.data.products;
}

export async function fetchProduct(id) {
  const { data } = await apiClient.get(`/products/${id}`);
  return data.data.product;
}

export async function createProduct(payload) {
  const { data } = await apiClient.post("/products", payload);
  return data.data.product;
}

export async function updateProduct(id, payload) {
  const { data } = await apiClient.put(`/products/${id}`, payload);
  return data.data.product;
}

export async function deleteProduct(id) {
  const { data } = await apiClient.delete(`/products/${id}`);
  return data.data;
}

export async function addVariant(productId, payload) {
  const { data } = await apiClient.post(`/products/${productId}/variants`, payload);
  return data.data.variant;
}

export async function updateVariant(variantId, payload) {
  const { data } = await apiClient.put(`/products/variants/${variantId}`, payload);
  return data.data.variant;
}

export async function deleteVariant(variantId) {
  const { data } = await apiClient.delete(`/products/variants/${variantId}`);
  return data.data;
}

export async function toggleVariantStock(variantId, isInStock) {
  const { data } = await apiClient.patch(`/products/variants/${variantId}/stock`, { isInStock });
  return data.data.variant;
}

export async function uploadProductImage(productId, file) {
  const formData = new FormData();
  formData.append("image", file);
  const { data } = await apiClient.post(`/products/${productId}/image`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data.data.product;
}

export async function removeProductImage(productId) {
  const { data } = await apiClient.delete(`/products/${productId}/image`);
  return data.data.product;
}
