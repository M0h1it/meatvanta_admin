import apiClient from "../../../lib/apiClient";

export async function fetchOrders({ status, page = 1, pageSize = 25 } = {}) {
  const { data } = await apiClient.get("/orders", { params: { status, page, pageSize } });
  return data.data;
}

export async function fetchOrder(id) {
  const { data } = await apiClient.get(`/orders/${id}`);
  return data.data.order;
}

export async function createOrder(payload) {
  const { data } = await apiClient.post("/orders", payload);
  return data.data.order;
}

export async function updateOrderStatus(id, status) {
  const { data } = await apiClient.patch(`/orders/${id}/status`, { status });
  return data.data.order;
}

export async function cancelOrder(id) {
  const { data } = await apiClient.post(`/orders/${id}/cancel`);
  return data.data.order;
}

export async function fetchDashboardStats() {
  const { data } = await apiClient.get("/orders/stats/summary");
  return data.data;
}