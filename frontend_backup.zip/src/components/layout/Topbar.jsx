import { useState, useRef, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";

export default function Topbar() {
  const { admin, logout } = useAuth();
  const navigate = useNavigate();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const notificationsRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (notificationsRef.current && !notificationsRef.current.contains(e.target)) {
        setNotificationsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  async function handleLogout() {
    await logout();
    navigate("/login", { replace: true });
  }

  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-md h-16 px-md md:px-lg border-b border-outline-variant bg-surface">
      {/* Shown on every screen size now - shorter label on mobile so it doesn't crowd the icons */}
      <h2 className="font-headline-sm text-headline-sm text-primary">
        <span className="hidden sm:inline">Star Halal Admin</span>
        <span className="sm:hidden">Star Halal</span>
      </h2>

      <div className="flex items-center gap-md ml-auto">
        <div className="relative" ref={notificationsRef}>
          <button
            onClick={() => setNotificationsOpen((o) => !o)}
            className="text-on-surface-variant hover:text-on-surface p-1 rounded hover:bg-surface-container-low"
            aria-label="Notifications"
          >
            <span className="material-symbols-outlined">notifications</span>
          </button>
          {notificationsOpen && (
            <div className="absolute right-0 mt-2 w-64 bg-surface-container-lowest border border-outline-variant rounded-lg shadow-lg z-50">
              <div className="px-md py-sm border-b border-outline-variant">
                <p className="font-label-bold text-label-bold text-on-surface">Notifications</p>
              </div>
              <div className="px-md py-lg text-center">
                <span className="material-symbols-outlined text-2xl text-outline-variant">notifications_off</span>
                <p className="text-sm text-on-surface-variant mt-1">No notifications yet.</p>
              </div>
            </div>
          )}
        </div>

        <Link
          to="/settings"
          className="text-on-surface-variant hover:text-on-surface p-1 rounded hover:bg-surface-container-low hidden sm:inline-flex"
          aria-label="Settings"
        >
          <span className="material-symbols-outlined">account_circle</span>
        </Link>

        <div className="text-right leading-tight hidden sm:block">
          <p className="font-body-md text-body-md font-semibold text-on-surface">{admin?.name}</p>
          <p className="text-xs text-on-surface-variant capitalize">{admin?.role}</p>
        </div>
        <button
          onClick={handleLogout}
          className="font-label-bold text-label-bold text-primary hover:text-on-primary-fixed-variant px-sm py-1 rounded transition-colors"
        >
          Logout
        </button>
      </div>
    </header>
  );
}